# Coding and Cookies Session 2

Mostly well split out into commits of Coding and Cookies session 2 :)

Finished site is on branch `gh-pages` (you can view it at http://hugodf.github.io/codingandcookies2)  

Starter-kit/Skeleton is on branch `starter`, can be download from http://hugodf.github.io/codingandcookies2/codingandcookies2.zip